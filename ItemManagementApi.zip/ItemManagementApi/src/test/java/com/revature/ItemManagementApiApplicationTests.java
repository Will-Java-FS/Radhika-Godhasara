package com.revature;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemManagementApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
