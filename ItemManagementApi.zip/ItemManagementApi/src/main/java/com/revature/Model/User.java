package com.revature.Model;

public class User {
}
